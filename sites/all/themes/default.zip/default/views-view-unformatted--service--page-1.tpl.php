<ul class="sidebar__list textside__list">
	<?php foreach ($rows as $id => $row): ?>
	 	<?php print $row; ?>                           
	<?php endforeach; ?>
</ul>