<li class="sidebar__item textside__item js-act">
    <a class="sidebar__link textside__link" href="<?=url('node/'.$row->nid);?>"><?=$row->node_title;?></a>
</li>